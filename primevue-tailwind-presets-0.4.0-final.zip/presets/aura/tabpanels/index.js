export default {
    root: 'bg-surface-0 dark:bg-surface-900 text-surface-900 dark:text-surface-0/80 outline-0 p-[1.125rem] pt-[0.875rem]'
};

export default {
    root: 'relative',
    mask: 'bg-black/40 rounded-md'
};

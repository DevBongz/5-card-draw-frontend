export default {
    root: {
        class: ['block absolute bg-surface-200 dark:bg-surface-700 rounded-full pointer-events-none'],
        style: 'transform: scale(0)'
    }
};

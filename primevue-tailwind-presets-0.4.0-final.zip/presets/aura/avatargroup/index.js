export default {
    root: {
        class: 'flex items-center'
    }
};

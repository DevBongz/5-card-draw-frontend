export default {
    icon: 'w-8 h-8 text-[2rem] mr-2'
};

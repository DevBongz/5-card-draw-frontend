export default {
    root: 'px-2 pt-4 pb-[1.125rem]'
};
